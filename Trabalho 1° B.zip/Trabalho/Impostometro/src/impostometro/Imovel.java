
package impostometro;

   

public class Imovel {
    public String nomeProprietario;
    public double imposto;
    public int mesesAtraso;   
    public int id;
    
    public Imovel(String nomeProprietario, double imposto, int mesesAtraso, int id){
    this.nomeProprietario = nomeProprietario;
    this.imposto = imposto;
    this.mesesAtraso = mesesAtraso;
    this.id = id;
    }
    
}
