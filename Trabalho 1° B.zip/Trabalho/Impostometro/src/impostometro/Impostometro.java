
package impostometro;


public class Impostometro {

    public static void main(String[] args) {
        Run run = new Run();
    }
    
    
}
    
