
package impostometro;

public class Municipio {
    
    public String nomeMunicipio;
    int imovelIndex = 0;
    Imovel[] imovel = new Imovel[20];
    
    public Municipio(String nome){
        this.nomeMunicipio = nome;
        loadImovel();
    }
    
    public void loadImovel(){
        imovel[0] = new Imovel("Nicolas", 500, 5, 0);
        imovel[1] = new Imovel("Davi", 200, 2, 1);
        imovel[2] = new Imovel("Caua", 300, 9, 2);
        imovelIndex = 2;
    }
    public void addImovel(String nome, double imposto, int multa){
        imovelIndex++;
        imovel[imovelIndex] = new Imovel(nome, imposto, multa, imovelIndex);
    }
    public double obterValorTotal(){
        double valorOriginal = imovel[3].imposto;
        double Multa = obterTaxaMulta(imovel[3].mesesAtraso);
        
        double result = valorOriginal * Multa;
        return result;
    }
    public double obterTaxaMulta(int mesesAtraso) {
        if (mesesAtraso <= 5) {
            return 1.01;
        } else if (mesesAtraso <= 8) {
            return 1.023;
        } else if (mesesAtraso <= 10) {
            return 1.03;
        } else if (mesesAtraso <= 12) {
            return 1.054;
        } else {
            return 1.10;
        }
    }
}
