
package impostometro;


public class Run {
    double result;
    public Run(){
        Municipio vilavelha = new Municipio("vila velha");
        loopApp(vilavelha);
    }
    public void loopApp(Municipio municipio){
        switch(InOut.leInt("Digite 0 para obter o valor total a ser pago, digite 1 para adcionar um imóvel; digite 2 para fechar o app")){
            case 0:
               int id = InOut.leInt("Qual é o id do imóvel");
               result = municipio.obterValorTotal();
                
                InOut.MsgDeInformacao("Multa", "O valor total da sua multa é de: " + result);
                    loopApp(municipio);
                break;
            case 1:
                String nome = InOut.leString("Digite o nome do proprietário:");
                double imposto = InOut.leDouble("Digite o imposto do imóvel:");
                int meses = InOut.leInt("Digite quantos meses de atraso:");
                municipio.addImovel(nome, imposto, meses);
                
                    loopApp(municipio);
                break;
            case 2:
                //Fechar o app
                break;
            default:
                break;
        }
    }
    
}
