
package poobet;

public class Jogo {
    int idJogo;
    String descritivo;
    double apostaMax;
    double premioMax;
    public Jogo(int idJogo, String descritivo, double apostaMax, double premioMax){
        this.idJogo = idJogo;
        this.descritivo = descritivo;
        this.apostaMax = apostaMax;
        this.premioMax = premioMax;
    }
    public void necessario(){
    }
}
