public class Main {
    public static void main(String[] args) {
        Oraculo oraculo = new Oraculo();
    }
}