public class Guerreiro {
    String nome;
    int vidas;
    int vitorias = 0;
    public Guerreiro(String nome){
        this.nome = nome;
    }
    public void setVidas(int vidas){
        this.vidas = vidas;
    }
}
